# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
Pipeline packaging.

This module contains classes and functionality for creating and validating pipeline configuration packages.
"""
