# Product Excellence Program

Siemens collects information about the use of our products by its users. This information will help us to improve our product features and functionality to better meet our customers’ needs.

All data collected under the Product Excellence Program will be aggregated and pseudonymized. No intellectual property information is collected or sent. Product performance is not affected.

The details regarding the types of data and the third parties engaged are described in the [Siemens Trust Center](https://www.siemens.com/global/en/company/about/compliance/dataprivacy/product-excellence-program.html).

If you wish to control the participation (or withdraw any given consent) with regard to the data collection under the Product Excellence Program, you can do so by calling `simaticai telemetry`.

## What happens when you give your consent?

During the building of the Pipeline Package:
- AI SDK
   - collects the information below
   - creates a telemetry_data.yml file and attaches to the Pipeline Package
- AI Inference Server
   - reads the information during Pipeline Import
   - sends the data to the Server anonymously

Collected data may include:
- environment info (CI/CD)
- python version
- simaticai version
- pipeline file extension
- platform os
- files types included in the created Pipeline Package
- usage of LocalPipelineRunner

Personal data (e.g., names, email addresses, passwords) will not be collected.

## Disclaimer

By deploying the created pipeline packages to AI Inference Server, the user accepts the terms of the previously provided consent and agrees to the transmission of the previously collected telemetry data about the packaging and testing environment. Siemens is not responsible for either the authenticity of the content of the consent or the collected data.
