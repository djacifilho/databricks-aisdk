# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
This module contains the schema files used in validation methods.

These JSON schema files describe the configuration YAML files' schema
for AI Inference Server.
"""
