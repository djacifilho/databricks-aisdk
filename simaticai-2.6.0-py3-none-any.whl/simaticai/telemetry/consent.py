# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.
import os
import sys
import platformdirs
import logging
from enum import Enum
from datetime import datetime
from pathlib import Path
from importlib import resources as module_resources
from importlib.metadata import version
from simaticai.helpers import yaml_helper

logging.basicConfig()
logging.getLogger().handlers = [logging.StreamHandler(sys.stdout)]
_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)

_APP_NAME = "simaticai"
_APP_AUTHOR = "Siemens"
_CONSENT_AFFIRMATIVE = ["allow", "accept", "true", "yes", "on", "enable", "1"]
_CONSENT_FILE_NAME = "consent.yml"
_CONSENT_ENV_VAR = "SIMATICAI_TELEMETRY"

CONSENT_KEY = "allow_telemetry"
CONSENT_KEY_TS = "timestamp"
CONSENT_KEY_SDK = "sdk_version"
CONSENT_KEY_METHOD = "consent_method"
CONSENT_COMMAND = "telemetry"
CONSENT_INFO = ""
consent_md_path = module_resources.files("simaticai") / "data" / "consent_info.md"
with consent_md_path.open("r") as f:
    CONSENT_INFO = f.read().strip()

CONSENT_EXCEPTION_TEXT = "Before using this application you need to make a statement about telemetry with the following command:\n"
CONSENT_EXCEPTION_TEXT += f"\tsimaticai {CONSENT_COMMAND}"

class ConsentStatus(Enum):
    UNDECIDED = "undecided"
    ALLOWED = "allowed"
    DENIED = "denied"

_CONSENT_OVERRIDE = ConsentStatus.UNDECIDED
_CONSENT_SOURCE = "none"

def get_consent_source() -> str:
    return _CONSENT_SOURCE

def get_user_config_dir_path() -> Path:
    return platformdirs.user_config_path(appname=_APP_NAME, appauthor=_APP_AUTHOR, roaming=True, ensure_exists=True)

def is_telemetry_allowed_by_env_var() -> ConsentStatus:
    if _CONSENT_ENV_VAR not in os.environ:
        return ConsentStatus.UNDECIDED
    choice = os.getenv(_CONSENT_ENV_VAR, "").lower() in _CONSENT_AFFIRMATIVE
    _logger.info(f"Telemetry is {'allowed' if choice else 'denied'} by environment variable.")
    if choice:
        return ConsentStatus.ALLOWED
    return ConsentStatus.DENIED

def read_telemetry_consent_file() -> tuple[dict, Path]:
    consent_file = get_user_config_dir_path() / _CONSENT_FILE_NAME
    data = yaml_helper.read_yaml(consent_file)
    if CONSENT_KEY not in data:
        raise AssertionError("Consent file exists, but the user's choice is not readable.")
    return data, consent_file

def is_telemetry_allowed_by_config_file() -> bool:
    try:
        data, _ = read_telemetry_consent_file()
        choice = data.get(CONSENT_KEY, False)
        if not isinstance(choice, bool):
            choice = str(choice).lower() in _CONSENT_AFFIRMATIVE
        _logger.info(f"Telemetry is {'allowed' if choice else 'denied'} by configuration file.")
        return choice
    except BaseException as error:
        global _CONSENT_SOURCE
        _CONSENT_SOURCE = "none"
        raise RuntimeError(f"\n\n{CONSENT_EXCEPTION_TEXT}\n") from error

def is_telemetry_allowed():
    global _CONSENT_SOURCE
    _CONSENT_SOURCE = "python method"
    if ConsentStatus.UNDECIDED != _CONSENT_OVERRIDE:
        return ConsentStatus.ALLOWED == _CONSENT_OVERRIDE

    _CONSENT_SOURCE = "environment variable"
    choice_env = is_telemetry_allowed_by_env_var()
    if ConsentStatus.UNDECIDED != choice_env:
        return ConsentStatus.ALLOWED == choice_env

    _CONSENT_SOURCE = "command line"
    return is_telemetry_allowed_by_config_file()

def set_telemetry_consent(allow: bool) -> Path:
    consent_file = get_user_config_dir_path() / _CONSENT_FILE_NAME
    try:
        with open(consent_file, "w") as f:
            # writing YAML manually to keep the file format as intended
            f.write(f"{CONSENT_KEY}: {'true' if allow else 'false'}\n")
            f.write(f"{CONSENT_KEY_TS}: '{datetime.now().isoformat()}'\n")
            f.write(f"{CONSENT_KEY_SDK}: '{version('simaticai')}'\n")
            f.write(f"{CONSENT_KEY_METHOD}: '{_CONSENT_SOURCE}'\n")
            f.write("information: |\n")
            for line in CONSENT_INFO.splitlines():
                f.write(f"    {line}\n")
    except BaseException as error:
        raise RuntimeError(f"Failed to save consent in '{consent_file}'.") from error
    return consent_file

def allow_telemetry() -> Path:
    global _CONSENT_SOURCE
    _CONSENT_SOURCE = "python method"
    return set_telemetry_consent(True)

def deny_telemetry() -> Path:
    global _CONSENT_SOURCE
    _CONSENT_SOURCE = "python method"
    return set_telemetry_consent(False)

def allow_telemetry_cli() -> Path:
    global _CONSENT_SOURCE
    _CONSENT_SOURCE = "command line"
    return set_telemetry_consent(True)

def deny_telemetry_cli() -> Path:
    global _CONSENT_SOURCE
    _CONSENT_SOURCE = "command line"
    return set_telemetry_consent(False)

def allow_telemetry_once():
    global _CONSENT_OVERRIDE, _CONSENT_SOURCE
    _CONSENT_SOURCE = "python method"
    _CONSENT_OVERRIDE = ConsentStatus.ALLOWED
    _logger.info("Telemetry is enabled for this session.")

def deny_telemetry_once():
    global _CONSENT_OVERRIDE, _CONSENT_SOURCE
    _CONSENT_SOURCE = "python method"
    _CONSENT_OVERRIDE = ConsentStatus.DENIED
    _logger.info("Telemetry is disabled for this session.")

__all__ = [
    "CONSENT_KEY",
    "CONSENT_KEY_TS",
    "CONSENT_KEY_SDK",
    "CONSENT_KEY_METHOD",
    "CONSENT_COMMAND",
    "CONSENT_INFO",
    "CONSENT_EXCEPTION_TEXT",
    "is_telemetry_allowed",
    "get_user_config_dir_path",
    "allow_telemetry",
    "deny_telemetry",
    "allow_telemetry_cli",
    "deny_telemetry_cli",
    "allow_telemetry_once",
    "deny_telemetry_once",
    "read_telemetry_consent_file",
    "get_consent_source",
]
