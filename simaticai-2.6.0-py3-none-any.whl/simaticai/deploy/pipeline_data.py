# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

import sys
import uuid
import logging
from typing import Optional

from simaticai.payloads import PipelineVariable, PipelineParameter


logging.basicConfig()
logging.getLogger().handlers = [logging.StreamHandler(sys.stdout)]
_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)


class PipelineData:

    def __init__(self, name: str, version: Optional[str] = None, desc: str = ""):
        """
        A newly initialized `Pipeline` will contain no `Component` or wire, just its name and version will be set.
        The name and version will define together the name of the zip file when the package is saved.

        Args:
            name (str): Name of the package
            desc (str): Package description (optional)
            version (str): Version of the package
        """

        self.name = name
        self.desc = desc

        self.version = version
        self.init_version = version  # initial version; used when version is not set in Pipeline.export() and save()
        self.save_version = version  # contains the version determined at exporting/saving
        self.package_id: Optional[uuid.UUID] = None

        self.author = 'AI SDK'

        self.components = {}
        self.wiring = {}
        self.parameters: list[PipelineParameter] = []

        self.periodicity = None
        self.timeshift_reference = []

        self.inputs: list[PipelineVariable] = []
        self.outputs: list[PipelineVariable] = []
        self.log_level = logging.INFO

    # Helper method returns index or None if the pipeline inputs/outputs contain the given variable
    def _get_io_index(self, io_list: list[PipelineVariable], variable: str) -> Optional[int]:
        for i, io in enumerate(io_list):
            if io.variableName == variable:
                return i
        return None

    def _get_io_variable(self, variable_name: str) -> Optional[PipelineVariable]:
        for io in self.inputs + self.outputs:
            if io.variableName == variable_name:
                return io
        return None

    def _get_parameter(self, parameter_name: str) -> Optional[PipelineParameter]:
        for param in self.parameters:
            if param.name == parameter_name:
                return param
        return None

    def _get_parameter_index(self, parameter_name: str) -> Optional[int]:
        for i, param in enumerate(self.parameters):
            if param.name == parameter_name:
                return i
        return None
